"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar, TrendingUp, Heart, Brain, Meh, Sun, Cloud, CloudRain } from "lucide-react"

interface EmotionEntry {
  id: string
  date: string
  time: string
  emotion: string
  intensity: number
  triggers: string[]
  notes: string
  mood: "positive" | "neutral" | "negative"
}

const emotions = [
  { name: "快乐", icon: "😊", color: "bg-yellow-100 text-yellow-800", mood: "positive" as const },
  { name: "平静", icon: "😌", color: "bg-blue-100 text-blue-800", mood: "positive" as const },
  { name: "兴奋", icon: "🤩", color: "bg-orange-100 text-orange-800", mood: "positive" as const },
  { name: "感激", icon: "🙏", color: "bg-green-100 text-green-800", mood: "positive" as const },
  { name: "中性", icon: "😐", color: "bg-gray-100 text-gray-800", mood: "neutral" as const },
  { name: "困惑", icon: "🤔", color: "bg-purple-100 text-purple-800", mood: "neutral" as const },
  { name: "疲惫", icon: "😴", color: "bg-indigo-100 text-indigo-800", mood: "neutral" as const },
  { name: "焦虑", icon: "😰", color: "bg-red-100 text-red-800", mood: "negative" as const },
  { name: "悲伤", icon: "😢", color: "bg-blue-200 text-blue-900", mood: "negative" as const },
  { name: "愤怒", icon: "😠", color: "bg-red-200 text-red-900", mood: "negative" as const },
]

const commonTriggers = [
  "工作压力",
  "人际关系",
  "健康问题",
  "财务担忧",
  "家庭事务",
  "学习压力",
  "社交媒体",
  "天气变化",
  "睡眠不足",
  "运动锻炼",
]

export default function EmotionTracker() {
  const [entries, setEntries] = useState<EmotionEntry[]>([])
  const [selectedEmotion, setSelectedEmotion] = useState("")
  const [intensity, setIntensity] = useState(5)
  const [selectedTriggers, setSelectedTriggers] = useState<string[]>([])
  const [notes, setNotes] = useState("")
  const [activeTab, setActiveTab] = useState("record")

  useEffect(() => {
    const savedEntries = localStorage.getItem("emotionEntries")
    if (savedEntries) {
      setEntries(JSON.parse(savedEntries))
    }
  }, [])

  const saveEntry = () => {
    if (!selectedEmotion) return

    const emotion = emotions.find((e) => e.name === selectedEmotion)
    const newEntry: EmotionEntry = {
      id: Date.now().toString(),
      date: new Date().toLocaleDateString("zh-CN"),
      time: new Date().toLocaleTimeString("zh-CN", { hour: "2-digit", minute: "2-digit" }),
      emotion: selectedEmotion,
      intensity,
      triggers: selectedTriggers,
      notes,
      mood: emotion?.mood || "neutral",
    }

    const updatedEntries = [newEntry, ...entries]
    setEntries(updatedEntries)
    localStorage.setItem("emotionEntries", JSON.stringify(updatedEntries))

    // 重置表单
    setSelectedEmotion("")
    setIntensity(5)
    setSelectedTriggers([])
    setNotes("")
  }

  const toggleTrigger = (trigger: string) => {
    setSelectedTriggers((prev) => (prev.includes(trigger) ? prev.filter((t) => t !== trigger) : [...prev, trigger]))
  }

  const getEmotionStats = () => {
    const last7Days = entries.slice(0, 7)
    const moodCounts = { positive: 0, neutral: 0, negative: 0 }

    last7Days.forEach((entry) => {
      moodCounts[entry.mood]++
    })

    return moodCounts
  }

  const getMoodIcon = (mood: string) => {
    switch (mood) {
      case "positive":
        return <Sun className="w-4 h-4 text-yellow-500" />
      case "neutral":
        return <Cloud className="w-4 h-4 text-gray-500" />
      case "negative":
        return <CloudRain className="w-4 h-4 text-blue-500" />
      default:
        return <Meh className="w-4 h-4" />
    }
  }

  const stats = getEmotionStats()

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-800 mb-2 flex items-center justify-center gap-2">
            <Heart className="w-8 h-8 text-pink-500" />
            情绪日记
          </h1>
          <p className="text-gray-600">记录、理解、成长 - 您的情绪健康伙伴</p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="record" className="flex items-center gap-2">
              <Heart className="w-4 h-4" />
              记录情绪
            </TabsTrigger>
            <TabsTrigger value="history" className="flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              历史记录
            </TabsTrigger>
            <TabsTrigger value="analysis" className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4" />
              情绪分析
            </TabsTrigger>
          </TabsList>

          <TabsContent value="record" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Brain className="w-5 h-5 text-purple-500" />
                  现在的感受如何？
                </CardTitle>
                <CardDescription>诚实地记录您当前的情绪状态，这是自我了解的第一步</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h3 className="text-sm font-medium mb-3">选择您的情绪</h3>
                  <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
                    {emotions.map((emotion) => (
                      <Button
                        key={emotion.name}
                        variant={selectedEmotion === emotion.name ? "default" : "outline"}
                        className={`h-auto p-3 flex flex-col items-center gap-2 ${
                          selectedEmotion === emotion.name ? emotion.color : ""
                        }`}
                        onClick={() => setSelectedEmotion(emotion.name)}
                      >
                        <span className="text-2xl">{emotion.icon}</span>
                        <span className="text-xs">{emotion.name}</span>
                      </Button>
                    ))}
                  </div>
                </div>

                <div>
                  <h3 className="text-sm font-medium mb-3">情绪强度 (1-10)</h3>
                  <div className="flex items-center gap-4">
                    <input
                      type="range"
                      min="1"
                      max="10"
                      value={intensity}
                      onChange={(e) => setIntensity(Number(e.target.value))}
                      className="flex-1"
                    />
                    <Badge variant="outline" className="min-w-[3rem] justify-center">
                      {intensity}
                    </Badge>
                  </div>
                </div>

                <div>
                  <h3 className="text-sm font-medium mb-3">可能的触发因素</h3>
                  <div className="flex flex-wrap gap-2">
                    {commonTriggers.map((trigger) => (
                      <Badge
                        key={trigger}
                        variant={selectedTriggers.includes(trigger) ? "default" : "outline"}
                        className="cursor-pointer"
                        onClick={() => toggleTrigger(trigger)}
                      >
                        {trigger}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div>
                  <h3 className="text-sm font-medium mb-3">详细记录</h3>
                  <Textarea
                    placeholder="描述您的感受、想法或今天发生的事情..."
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    className="min-h-[100px]"
                  />
                </div>

                <Button onClick={saveEntry} disabled={!selectedEmotion} className="w-full">
                  保存记录
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="history" className="space-y-4">
            {entries.length === 0 ? (
              <Card>
                <CardContent className="text-center py-8">
                  <p className="text-gray-500">还没有情绪记录，开始记录您的第一条吧！</p>
                </CardContent>
              </Card>
            ) : (
              entries.map((entry) => (
                <Card key={entry.id}>
                  <CardContent className="pt-6">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <span className="text-2xl">{emotions.find((e) => e.name === entry.emotion)?.icon}</span>
                        <div>
                          <h3 className="font-medium">{entry.emotion}</h3>
                          <p className="text-sm text-gray-500">
                            {entry.date} {entry.time}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {getMoodIcon(entry.mood)}
                        <Badge variant="outline">强度 {entry.intensity}</Badge>
                      </div>
                    </div>

                    {entry.triggers.length > 0 && (
                      <div className="mb-3">
                        <p className="text-sm text-gray-600 mb-1">触发因素：</p>
                        <div className="flex flex-wrap gap-1">
                          {entry.triggers.map((trigger) => (
                            <Badge key={trigger} variant="secondary" className="text-xs">
                              {trigger}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}

                    {entry.notes && <p className="text-sm text-gray-700 bg-gray-50 p-3 rounded-md">{entry.notes}</p>}
                  </CardContent>
                </Card>
              ))
            )}
          </TabsContent>

          <TabsContent value="analysis" className="space-y-6">
            <div className="grid md:grid-cols-3 gap-4">
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center gap-2 mb-2">
                    <Sun className="w-5 h-5 text-yellow-500" />
                    <h3 className="font-medium">积极情绪</h3>
                  </div>
                  <p className="text-2xl font-bold text-yellow-600">{stats.positive}</p>
                  <p className="text-sm text-gray-500">最近7次记录</p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center gap-2 mb-2">
                    <Cloud className="w-5 h-5 text-gray-500" />
                    <h3 className="font-medium">中性情绪</h3>
                  </div>
                  <p className="text-2xl font-bold text-gray-600">{stats.neutral}</p>
                  <p className="text-sm text-gray-500">最近7次记录</p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center gap-2 mb-2">
                    <CloudRain className="w-5 h-5 text-blue-500" />
                    <h3 className="font-medium">消极情绪</h3>
                  </div>
                  <p className="text-2xl font-bold text-blue-600">{stats.negative}</p>
                  <p className="text-sm text-gray-500">最近7次记录</p>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>情绪健康建议</CardTitle>
                <CardDescription>基于您的情绪记录，为您提供个性化建议</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {stats.positive >= stats.negative ? (
                  <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                    <h4 className="font-medium text-green-800 mb-2">🌟 情绪状态良好</h4>
                    <p className="text-green-700 text-sm">
                      您最近的情绪状态相对积极，继续保持这种良好的心态。建议继续进行让您感到快乐的活动。
                    </p>
                  </div>
                ) : (
                  <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                    <h4 className="font-medium text-blue-800 mb-2">💙 需要关注情绪健康</h4>
                    <p className="text-blue-700 text-sm">
                      最近可能经历了一些挑战。建议尝试深呼吸、冥想或与信任的人交流。如果持续感到困扰，考虑寻求专业帮助。
                    </p>
                  </div>
                )}

                <div className="p-4 bg-purple-50 rounded-lg border border-purple-200">
                  <h4 className="font-medium text-purple-800 mb-2">🧘 日常建议</h4>
                  <ul className="text-purple-700 text-sm space-y-1">
                    <li>• 每天花10分钟进行正念冥想</li>
                    <li>• 保持规律的睡眠作息</li>
                    <li>• 适量运动，释放内啡肽</li>
                    <li>• 记录感恩日记，关注积极面</li>
                    <li>• 与亲友保持良好沟通</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
